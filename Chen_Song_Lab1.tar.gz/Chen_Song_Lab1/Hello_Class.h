#include <iostream>

using namespace std;

class Hello_Class {
	public:
		Hello_Class(int i);
		void print_hello();
	private:
      		string output_string;
};

